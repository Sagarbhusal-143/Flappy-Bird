using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace FlappyBird
{
    public enum GameState
    {
        Start,
        GamePlay,
        GamePause,
        Dead
    }

public class BirdController : MonoBehaviour
    {
       protected Rigidbody2D _rb;
        [SerializeField] protected float _forwardSpeed = 5f;
        [SerializeField] protected float _jumpStrength = 2f;
        [SerializeField] protected float _rotationSpeed = 10f;
        protected virtual void Start()
        {
            _rb = GetComponent<Rigidbody2D>();
            _rb.velocity = new Vector2(_forwardSpeed, 0f);
        }

        protected virtual void Update()
        {
            
        }

        protected virtual void FixedUpdate()
        {
            
        }

        protected bool IsTap()
        {
            if (Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Space))
                return true;
            return false;
        }

        protected float ClampAngle(float angle, float min, float max)
        {
            return Mathf.Clamp((angle <= 180) ? angle : -(360 - angle), min, max);
        }
    }
}